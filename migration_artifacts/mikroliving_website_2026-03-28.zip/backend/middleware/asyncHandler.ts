import { NextFunction, Request, Response } from "express";

export function asyncHandler<T extends (req: Request, res: Response, next: NextFunction) => unknown>(handler: T) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
}
